# PDF Automation Tool
# Merge PDFs
# Split PDFs
# Extract text
# Libraries: PyPDF2
import os
from PyPDF2 import PdfReader, PdfWriter
 
 
def merge_pdfs(pdf_list, output_path):
    """Merge multiple PDF files into one PDF."""
    pdf_writer = PdfWriter()
 
    for pdf in pdf_list:
        if not os.path.exists(pdf):
            print(f"Error: File not found - {pdf}")
            return
 
        pdf_reader = PdfReader(pdf)
        for page in pdf_reader.pages:
            pdf_writer.add_page(page)
 
    with open(output_path, "wb") as output_pdf:
        pdf_writer.write(output_pdf)
 
    print(f"Merged PDF saved to: {output_path}")
 
 
def split_pdf(input_pdf, output_folder):
    """Split a PDF into individual pages."""
    if not os.path.exists(input_pdf):
        print(f"Error: File not found - {input_pdf}")
        return
 
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
 
    pdf_reader = PdfReader(input_pdf)
 
    for page_num, page in enumerate(pdf_reader.pages, start=1):
        pdf_writer = PdfWriter()
        pdf_writer.add_page(page)
 
        output_path = os.path.join(output_folder, f"page_{page_num}.pdf")
        with open(output_path, "wb") as output_pdf:
            pdf_writer.write(output_pdf)
 
    print(f"Split PDF saved in folder: {output_folder}")
 
 
def extract_text_from_pdf(input_pdf):
    """Extract text from a PDF file."""
    if not os.path.exists(input_pdf):
        print(f"Error: File not found - {input_pdf}")
        return ""
 
    pdf_reader = PdfReader(input_pdf)
    text = ""
 
    for page_num, page in enumerate(pdf_reader.pages, start=1):
        page_text = page.extract_text()
        if page_text:
            text += f"\n--- Page {page_num} ---\n"
            text += page_text
 
    return text
 
 
if __name__ == "__main__":
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
 
    print("Files available in current folder:")
    for file in os.listdir(BASE_DIR):
        print("-", file)
 
    # Replace these names with your actual PDF filenames
    pdf_files = [
        os.path.join(BASE_DIR, "file1.pdf"),
        os.path.join(BASE_DIR, "file2.pdf")
    ]
 
    # Merge PDFs
    merge_pdfs(pdf_files, os.path.join(BASE_DIR, "merged_output.pdf"))
 
    # Split merged PDF
    split_pdf(
        os.path.join(BASE_DIR, "merged_output.pdf"),
        os.path.join(BASE_DIR, "split_pages")
    )
 
    # Extract text from merged PDF
    extracted_text = extract_text_from_pdf(
        os.path.join(BASE_DIR, "merged_output.pdf")
    )
 
    if extracted_text:
        text_file = os.path.join(BASE_DIR, "extracted_text.txt")
        with open(text_file, "w", encoding="utf-8") as file:
            file.write(extracted_text)
        print(f"Extracted text saved to: {text_file}")
 
    print("\nAll PDF operations completed successfully!")
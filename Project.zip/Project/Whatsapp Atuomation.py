# WhatsApp Message Scheduler
# Schedule messages automatically
# Libraries: pywhatkit
import pywhatkit
import datetime

def send_whatsapp_message(phone_number, message):
    # Current datetime
    now = datetime.datetime.now()
    
    # Add 15 seconds
    send_time = now + datetime.timedelta(seconds=1)
    
    print(f"Message to {phone_number} will be sent at {send_time.strftime('%Y-%m-%d %H:%M:%S')}")
    # Here you would integrate with your WhatsApp automation library
 
phone_number = "+918320455923" 
message = "merged_output.pdf has been created successfully!"
pywhatkit.sendwhatmsg_instantly(phone_number, message)
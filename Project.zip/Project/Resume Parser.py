# Resume Parser
# Extract names, skills, emails from resumes
# Libraries: re, NLTK
import re
import nltk
from nltk.tokenize import word_tokenize
import nltk
nltk.download('punkt')
nltk.download('punkt_tab')  
nltk.download('stopwords')
nltk.download('wordnet')
nltk.download('averaged_perceptron_tagger')


text = "Krutarth is building a Resume Parser."
tokens = word_tokenize(text)
print(tokens)  # ['Krutarth', 'is', 'building', 'a', 'Resume', 'Parser', '.']


def extract_name(text):
    # Use regex to find potential names (capitalized words)
    name_pattern = re.compile(r'\b[A-Z][a-zA-Z]*\b')
    names = name_pattern.findall(text)
    return names[0] if names else None

def extract_email(text):
    email_pattern = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
    email = email_pattern.search(text)
    return email.group() if email else None

def extract_phone(text):
    phone_pattern = re.compile(r'\b\d{10}\b')
    phone = phone_pattern.search(text)
    return phone.group() if phone else None

def extract_skills(text):
    # This is a very basic example. You can expand this with a more comprehensive list of skills.
    skills = ['Python', 'Java', 'C++', 'SQL', 'Machine Learning', 'Data Analysis']
    found_skills = [skill for skill in skills if skill in text]
    return found_skills

def extract_experience(text):
    # This is a very basic example. You can expand this with more complex patterns.
    experience_pattern = re.compile(r'(\d+ years of experience)')
    experience = experience_pattern.search(text)
    return experience.group() if experience else None

def parse_resume(text):
    name = extract_name(text)
    email = extract_email(text)
    phone = extract_phone(text)
    skills = extract_skills(text)
    experience = extract_experience(text)

    return {
        'name': name,
        'email': email,
        'phone': phone,
        'skills': skills,
        'experience': experience
    }
# Example usage
resume_text = """Krutarth Patel
email: ptkrutarth1184@gmail.com
phone: +91 8488833930
skills: ['Python', 'Java']
experience: Fresh Graduate with 0 years of experience"""
parsed_data = parse_resume(resume_text)
print(parsed_data)
# Web Scraper for Price Tracking
# Track product prices
# Notify when prices drop
# Libraries: requests, BeautifulSoup
import requests
from bs4 import BeautifulSoup
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import re
 
 
def get_price(url):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9"
    }
 
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
 
        soup = BeautifulSoup(response.content, "html.parser")
 
        selectors = [
            {"id": "priceblock_ourprice"},
            {"id": "priceblock_dealprice"},
            {"class": "a-price-whole"}
        ]
 
        for selector in selectors:
            price_tag = soup.find("span", selector)
            if price_tag:
                price_text = price_tag.get_text().strip()
                match = re.search(r"[\d,.]+", price_text)
                if match:
                    return float(match.group().replace(",", ""))
 
        return None
 
    except Exception as e:
        print(f"Error fetching price: {e}")
        return None
 
 
def send_email_alert(product_url, current_price, target_price):
    sender_email = "ptkrutarth1184@gmail.com"
    sender_password = "ubky rint jhnl txra"
    receiver_email = "burmanjai5@gmail.com"
 
    subject = "Price Drop Alert!"
    body = f"Good news!\n\nThe product price has dropped to ₹{current_price:.2f}.\nYour target price was ₹{target_price:.2f}.\n\nBuy now: {product_url}"
 
    msg = MIMEMultipart()
    msg["From"] = sender_email
    msg["To"] = receiver_email
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))
 
    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.send_message(msg)
        server.quit()
        print("Email alert sent successfully!")
    except Exception as e:
        print(f"Failed to send email: {e}")
url = "https://www.amazon.in/XYXX-Solid-Regular-XY_CR14_Polo-Tshirt_1_Blue/dp/B0CBBB5843/?_encoding=UTF8&pd_rd_w=onSUp&content-id=amzn1.sym.de84ee3f-a07f-47cd-ac44-50f5d6cbb587&pf_rd_p=de84ee3f-a07f-47cd-ac44-50f5d6cbb587&pf_rd_r=KZPBXX1HA4S7184XVGBB&pd_rd_wg=fHZK1&pd_rd_r=002f32c6-fbc1-4966-9e5f-e36ce5492660&ref_=pd_hp_d_btf_a2i_gw_cml&th=1&psc=1"
target_price = 1000.00
 
current_price = get_price(url)
 
if current_price is not None:
    print(f"Current Price: ₹{current_price}")
print(f"Target Price: ₹{target_price}")
 
if current_price <= target_price:
        print("Price dropped! Sending email alert...")
        send_email_alert(url, current_price, target_price)
else:
        print(f"Price is still above your target of ₹{target_price:.2f}")
 
print("Price not found.")
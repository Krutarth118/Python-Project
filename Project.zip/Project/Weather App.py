# Weather App
# Fetch live weather details
# Libraries: requests
import requests

def get_weather(city):
    api_key = "9f344b1772010b26ec243d5dd36b12c0"  # Replace with your valid OpenWeatherMap API key
    base_url = "http://api.openweathermap.org/data/2.5/weather"
    
    params = {
        "q": city,
        "appid": api_key,
        "units": "metric"
    }
    
    response = requests.get(base_url, params=params)
    if response.status_code == 200:
        data = response.json()
        weather_desc = data['weather'][0]['description']
        temp = data['main']['temp']
        print(f"Weather in {city}: {weather_desc}, Temperature: {temp}°C")
    else:
        print("City not found or API error.")

if __name__ == "__main__":
    city = input("Enter city name: ")
    get_weather(city)

# YouTube Video Downloader
# Download videos/audio
# Libraries: pytube

import os
from yt_dlp import YoutubeDL
 
 
def download_video(url, path="."):
    """Download a YouTube video in the highest available quality."""
    try:
        os.makedirs(path, exist_ok=True)
 
        ydl_opts = {
            'outtmpl': os.path.join(path, '%(title)s.%(ext)s'),
            'format': 'best[ext=mp4]/best',
                        'noplaylist': True,
        }
 
        with YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            print(f"Connecting to: {info['title']}")
            print("Downloading...")
            ydl.download([url])
            print(f"Video downloaded successfully: {info['title']}")
            print(f"Saved to: {os.path.abspath(path)}")
 
    except Exception as e:
        print(f"Error downloading video: {e}")
 
 
if __name__ == "__main__":
    video_url = input("Enter YouTube URL: ").strip()
 
    if not video_url:
        print("Error: You must enter a valid YouTube URL.")
    else:
        download_path = input("Enter download path (default is current directory): ").strip() or "."
        download_video(video_url, download_path)
#  Email Automation Tool
# Send automatic emails/reminders
# Libraries: smtplib, email
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from getpass import getpass
def send_email(subject, body, to_email):
    from_email = "ptkrutarth1184@gmail.com"
    password = "ubky rint jhnl txra"
    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(from_email, password)
        msg = MIMEText(body)
        msg['Subject'] = subject
        msg['From'] = from_email
        msg['To'] = to_email
        server.send_message(msg)
        print(f"Email sent to {to_email} successfully!")    
    except Exception as e:
        print(f"Failed to send email: {e}") 
    finally:
        server.quit()
def main():
    subject = input("Enter email subject: ")
    body = input("Enter email body: ")
    to_email = input("Enter recipient's email address: ")
    send_email(subject, body, to_email) 
if __name__ == "__main__":
    main()
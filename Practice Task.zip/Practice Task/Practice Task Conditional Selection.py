# Task:
import numpy as np

# 1. Create arr = [10, 15, 20, 25, 30]
a = np.array([10, 15, 20, 25, 30])
# 2. Select values greater than 18
print(a[a > 18])
# 3. Replace values less than 18 with -1
a[a < 18] = -1
print(a)
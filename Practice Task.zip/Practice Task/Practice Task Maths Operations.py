# Task Math Operations on a 1D Array(*args): 
# 1. Create an array: [2, 4, 6, 8, 10]
# 2. Multiply all elements by 3
# 3. Find the average, sum, and standard deviation

import numpy as np

arr = np.array([2, 4, 6, 8, 10])
arr = arr * 3
print("New Array:", arr)
print("Sum of elements:", np.sum(arr))
print("Mean of elements:", np.mean(arr))
print("Standard deviation:", np.std(arr))


#  Simulate 10 dice rolls

import numpy as np

rolls = np.random.randint(1, 7, size=10)
print(rolls)
flips = np.random.randint(0, 2, size=100)
heads_count = np.sum(flips == 0)
tails_count = np.sum(flips == 1)
print(f"Heads: {heads_count}, Tails: {tails_count}")
# Task:
import numpy as np
# 1. Create a 1D array from 1 to 12.  
a = np.array(range(1, 13))

# 2. Reshape it to 3x4.  
reshaped = np.reshape(a, (3, 4))

# 3. Flatten it back to 1D.  
b = reshaped.flatten()
print(b)

# 4. Stack two 1D arrays vertically and .
a = np.array([1, 2, 3])
b = np.array([4, 5, 6])
c = np.vstack((a, b))
print(c)

# horizontally
a = np.array([[1], [2], [3]])
b = np.array([[4], [5], [6]])
c = np.hstack((a, b))
print(c)
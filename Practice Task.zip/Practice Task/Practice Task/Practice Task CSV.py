# Task:
import numpy as np
# 1. Load 'sales.csv' with columns: product, price, quantity  
data = np.genfromtxt(r'D:\Internship\python\Numpy\sales.csv', delimiter=',', skip_header=1, usecols=(1, 2))
# 2. Calculate average price and total quantity  
print(np.average(data[:, 0]))  # Average price
print(np.sum(data[:, 1]))      # Total quantity
# 3. Save the result to 'summary.csv'
summary = np.array([[np.mean(data[:, 0]), np.sum(data[:, 1])]])
np.savetxt(r'D:\Internship\python\Numpy\summary.csv', summary, delimiter=',', fmt='%.2f', header='Average Price,Total Quantity', comments='')
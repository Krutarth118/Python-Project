# Task Broadcasting and Universal Functions(*args):
# 1. Create array a = [1, 2, 3, 4]
# 2. Add 5 to each element (broadcasting)
# 3. Calculate square and square root (ufuncs)
import numpy as np

a = np.array([1, 2, 3, 4])
a_pluse = a +5
print("Array after adding 5:", a_pluse)
print("Square of the array:", np.square(a_pluse))
print("Square root of the array:", np.sqrt(a_pluse))